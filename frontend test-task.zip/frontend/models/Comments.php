<?php

namespace app\models;

use yii\db\ActiveRecord;

class Comments extends ActiveRecord
{
}