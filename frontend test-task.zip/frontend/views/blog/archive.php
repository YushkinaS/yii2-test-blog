<?php
use yii\helpers\Html;
use yii\widgets\LinkPager;


use yii\grid\GridView;
use yii\data\ActiveDataProvider;

/*
$dataProvider = new ActiveDataProvider([
    'query' => $query,
    'pagination' => [
        'pageSize' => 4,
    ],
]);
echo GridView::widget([
    'dataProvider' => $dataProvider,
]);
*/

?>
<h1>Архив</h1>
<ul>
<?php foreach ($table as $row): ?>
    <li>
        <?= Html::encode("{$row->title} ({$row->content})") ?>:
        <?= $row->author ?>
    </li>
<?php endforeach; ?>
</ul>

<?= LinkPager::widget(['pagination' => $pagination]) ?>