<?php
namespace frontend\controllers;

//убрать лишние юзы

use Yii;
use yii\base\InvalidParamException;
use yii\web\BadRequestHttpException;
use yii\web\Controller;
use yii\filters\VerbFilter;
use yii\filters\AccessControl;
use common\models\LoginForm;
use frontend\models\PasswordResetRequestForm;
use frontend\models\ResetPasswordForm;
use frontend\models\SignupForm;
use frontend\models\ContactForm;
use yii\data\Pagination;
use app\models\Posts;

/**
 * Site controller
 */
class BlogController extends Controller
{
    

    /**
     * Displays homepage.
     *
     * @return mixed
     */
	public function actionIndex( $post_slug = '')
    {
        $query = Posts::find();

        $pagination = new Pagination([
            'defaultPageSize' => $query->count(),
            'totalCount' => $query->count(),
        ]);

        $data = $query->orderBy('id')
            ->offset($pagination->offset)
            ->limit($pagination->limit)
            ->all();

		if (empty($post_slug)) 
		{
			return $this->render('archive', [
				'table' => $data,
				'pagination' => $pagination,
			]);			
		}
		else 
		{
			return $this->render('single', [
				'table' => $data,
				'pagination' => $pagination,
			]);			
		}
    }

}
